import { defineStore } from 'pinia'

export const useTextStore = defineStore('textStore', {
  state: () => ({
    en: {
      block1_H1: `Hello,<br /> this is my <br /> portfolio`,
      block2_H2: `About me`,
      block2_H3_part1: `Education`,
      block2_P_part1: `I am currently a 3nd year student at RTU MIREA<br />
        majoring in "Fullstack Development" (2026).`,
      block2_H3_part2: `Goals`,
      block2_P_part2: `Gain work experience, more knowledge and skills in my field.<br />
        Currently looking for an internship<br />
        where I can work while studying at the university.<br />
I'm happy to participate in one-off projects and hackathons.`,
      block3_H2: `Skills`,
      block3_H3_part1: `General knowledge`,
      block3_P_part1: `I have experience with Vue.js, React.js, <br />
      JavaScript, TypeScript, SASS, SCSS, <br />
      CSS, HTML, Python, C++, C#,<br />
      PostgreSQL, Flutter + Dart<br />`,
      block3_H3_part2: `Tech stacks`,
      block3_P_part2: `My main stacks are React and Vue.<br />
I most often write using JavaScript for the functional part of the project,<br />
"complex" animations, backend integration, etc.<br />
I prefer the SASS preprocessor for comfortable and concise<br />
style writing,<br />
and classic HTML for markup.`,
      block4_H2: `Projects`,
      block4_H3: `Online code editor`,
      block4_P: `For my own needs, I built an online JavaScript code editor<br />
    designed for writing simple code and solving small tasks in this language.<br />
    It supports displaying objects and lists, and also correctly handles promises and timeouts.<br />
    The project is available at the <a class="a" href="https://onlineeditor.ivanjhn.ru/" target="_blank">link</a> - <a class="a" href="https://onlineeditor.ivanjhn.ru/" target="_blank">https://onlineeditor.ivanjhn.ru/</a>`,
      block5_H2: `Me`,
      block5_H3: `My interests`,
      block5_P: `In my free time I enjoy<br />
    drawing, gaming<br />
    and studying interesting animations and frontend tricks.`,
      form_H2: `Write to me`,
      form_label1: `Your email address`,
      form_label2: `How to address you`,
      form_label3: `Describe what you need`,
      form_button_text: `Submit request`,
      form_button_status: `Sending...`,
      form_reset_button: `Submit new request`,
      form_success_msg: `Thank you for your request! I'll contact you shortly.`,
      form_errors: {
        emailRequired: 'Email is required',
        emailInvalid: 'Invalid email format',
        emailTooLong: 'Email is too long',
        nameRequired: 'Please provide your name',
        nameTooShort: 'Name is too short',
        nameTooLong: 'Name is too long',
        descriptionRequired: 'Please describe your project',
        descriptionTooShort: 'Please provide more details (min 15 characters)',
        descriptionTooLong: 'Is too long description (max 400 characters)',
        submitError: 'Request submission failed',
      },
      card_name: `Timofeev Ivan`,
      card_country: `Moscow`,
      modal_window: `Drag`,
    },
    ru: {
      block1_H1: `Здравствуйте,<br /> это моё <br /> портфолио`,
      block2_H2: `Обо мне`,
      block2_H3_part1: `Обучение`,
      block2_P_part1: `Сейчас я учусь на 3м курсе в РТУ МИРЭА<br />
            на направлении “Фуллстек разработка” 2026 г.`,
      block2_H3_part2: `Цели`,
      block2_P_part2: ` Получить опыт работы, больше знаний и навыков в своей области.<br />
            На данный момент ищу стажировку,<br />
            на которой смогу работать параллельно учёбе в вузе.<br />
            Я буду рад принять участие в разовых проектах и хакатонах`,
      block3_H2: `Навыки`,
      block3_H3_part1: `Общие знания`,
      block3_P_part1: `У меня есть опыт работы с Vue.js, React.js, <br />
      JavaScript, TypeScript, SASS, SCSS, <br />
      CSS, HTML, Python, C++, C#,<br />
      PostgreSQL, Flutter + Dart<br />
    `,
      block3_H3_part2: `Стеки`,
      block3_P_part2: `Мои основные стеки - React и Vue.<br />
    Чаще всего пишу используя JavaScript для функциональной части проекта,<br />
    "сложных" анимаций, связки с бекэндом и т.д.,<br />
    Предпочитаю препроцессор SASS для комфортного и лаконичного<br />
    написания стилей,<br />
    И классический HTML для разметки.`,
      block4_H2: `Проекты`,
      block4_H3: `Онлайн редакотор кода`,
      block4_P: `В рамках своих потребностей я реализовал онлайн редактор JavaScrip кода, <br />который преднозначен для написания простого кода и решения задачек на этом языке.<br />В нем реализовано отображение объектов и списков, а так же корректно обрботаны промисы и таймауты. <br />Проект доступен по <a class="a" href="https://onlineeditor.ivanjhn.ru/" target="_blank">ссылке</a> - <a class="a" href="https://onlineeditor.ivanjhn.ru/" target="_blank">https://onlineeditor.ivanjhn.ru/</a>`,
      block5_H2: `Я`,
      block5_H3: `Мои интересы`,
      block5_P: `Свободное время я люблю проводить за<br />
    рисованием, играми<br />
    и изучением интересных анимаций и фишек во фронтенде.`,
      form_H2: `Напишите мне`,
      form_label1: `Напишите ваш email`,
      form_label2: `Как к вам обращаться`,
      form_label3: `Опишите что вам нужно`,
      form_button_text: `Отправить запрос`,
      form_button_status: `Отправка...`,
      form_reset_button: `Отправить новый запрос`,
      form_success_msg: `Спасибо за вашу заявку! Я свяжусь с вами в ближайшее время.`,
      form_errors: {
        emailRequired: 'Email обязателен',
        emailInvalid: 'Некорректный email',
        emailTooLong: 'Слишком длинный email',
        nameRequired: 'Укажите, как к вам обращаться',
        nameTooShort: 'Слишком короткое имя',
        nameTooLong: 'Слишком длинное имя',
        descriptionRequired: 'Опишите ваш проект',
        descriptionTooShort: 'Опишите подробнее (минимум 15 символов)',
        descriptionTooLong: 'Слишком длинное описание (максимум 400 символов)',
        submitError: 'Ошибка при отправке запроса',
      },
      card_name: `Тимофеев Иван`,
      card_country: `Москва`,
      modal_window: `Перетаскивание`,
    },
    chooseLang: true,
  }),
  persist: true,
  getters: {},

  actions: {
    switchLanguage() {
      this.chooseLang = !this.chooseLang
    },
  },
})
