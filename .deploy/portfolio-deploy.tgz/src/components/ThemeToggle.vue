<script>
export default {
  props: {
    scroll: {
      type: Number,
      required: true,
    },
  },

  data() {
    return { theme_flag: true, firstBlock: null }
  },

  methods: {
    switch_theme_var() {
      console.log('here')
      if (this.theme_flag) {
        localStorage.setItem('theme', false)
        this.theme_flag = false
      } else {
        localStorage.setItem('theme', true)
        this.theme_flag = true
      }
      this.switch_theme()
    },
    switch_theme() {
      console.log(this.theme_flag)
      if (!this.theme_flag) {
        document.documentElement.style.setProperty('--white', '#090909')
        document.documentElement.style.setProperty('--white-grey', '#1e1e1e')
        document.documentElement.style.setProperty('--white-blue-grey', '#141515')
        document.documentElement.style.setProperty('--white-light-grey', '#0c0c0c')
        document.documentElement.style.setProperty('--light-grey', '#262626')
        document.documentElement.style.setProperty('--pre-grey', '#3b3b3b')
        document.documentElement.style.setProperty('--grey', '#c0c0c0')
        document.documentElement.style.setProperty('--dark-grey', '#3e3e3e')
        document.documentElement.style.setProperty('--black', '#f6f6f6')
        document.documentElement.style.setProperty(
          '--black-transparent-hight',
          'rgba(159, 154, 210, 0.75)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-medium',
          'rgba(159, 154, 210, 0.34)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-pre-low',
          'rgba(159, 154, 210, 0.22)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-low',
          'rgba(159, 154, 210, 0.10)',
        )
        document.documentElement.style.setProperty('--coral', '#b52e2e')
        document.documentElement.style.setProperty('--light-coral', '#ff5f56')
        document.documentElement.style.setProperty('--emerald', '#2d835c')
        document.documentElement.style.setProperty('--dark-emerald', '#226547')
        document.documentElement.style.setProperty('--dark-blue', '#494957')
        document.documentElement.style.setProperty('--light-blue', '#6d6d9f')
        document.documentElement.style.setProperty('--img', '1')
        document.documentElement.style.setProperty('--img-reverse', '0')
        document.documentElement.style.setProperty('--img-opacity', '0.85')
        document.documentElement.style.setProperty('--reset-btn-bg', '#dedfdf')
      } else {
        document.documentElement.style.setProperty('--white', '#f1f0f7')
        document.documentElement.style.setProperty('--white-grey', '#f4f4f4')
        document.documentElement.style.setProperty('--white-blue-grey', '#e9ecef')
        document.documentElement.style.setProperty('--white-light-grey', '#f8f9fa')
        document.documentElement.style.setProperty('--light-grey', '#ddd')
        document.documentElement.style.setProperty('--pre-grey', '#cccccc')
        document.documentElement.style.setProperty('--grey', '#555')
        document.documentElement.style.setProperty('--dark-grey', '#3e3e3e')
        document.documentElement.style.setProperty('--black', '#090909')
        document.documentElement.style.setProperty(
          '--black-transparent-hight',
          'rgba(61, 57, 81, 0.7)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-medium',
          'rgba(61, 57, 81, 0.24)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-pre-low',
          'rgba(61, 57, 81, 0.19)',
        )
        document.documentElement.style.setProperty(
          '--black-transparent-low',
          'rgba(61, 57, 81, 0.08)',
        )
        document.documentElement.style.setProperty('--coral', '#ff4444')
        document.documentElement.style.setProperty('--light-coral', '#ff5f56')
        document.documentElement.style.setProperty('--emerald', '#42b983')
        document.documentElement.style.setProperty('--dark-emerald', '#3aa876')
        document.documentElement.style.setProperty('--dark-blue', '#57577f')
        document.documentElement.style.setProperty('--light-blue', '#464667')
        document.documentElement.style.setProperty('--img', '0')
        document.documentElement.style.setProperty('--img-reverse', '1')
        document.documentElement.style.setProperty('--img-opacity', '1')
        document.documentElement.style.setProperty('--reset-btn-bg', '#e8eaeb')
      }
    },
  },

  watch: {
    scroll(newScroll) {
      const switcher = document.querySelector('.theme_switch__bg')
      if (newScroll > this.firstBlock + 40) {
        switcher.style.position = 'fixed'
        switcher.style.right = '8%'
        switcher.style.top = '4%'
      } else if (newScroll < this.firstBlock - 40) {
        switcher.style.position = 'absolute'
        switcher.style.right = '3%'
        switcher.style.top = '4%'
      }
    },
  },
  mounted() {
    const theme = localStorage.getItem('theme')
    if (theme != null) {
      if (theme == 'false') {
        this.theme_flag = false
      } else {
        this.theme_flag = true
      }
      this.switch_theme()
    }

    this.firstBlock = document.querySelector('.main-first').clientHeight
  },
  beforeUnmount() {},
}
</script>

<template>
  <div
    class="theme_switch__bg"
    :class="{
      sticky: scroll >= firstBlock + 40,
      notSticky: scroll < firstBlock + 40 && scroll > firstBlock - 40,
    }"
  >
    <img
      class="sun_icon"
      :class="{
        sun_off: !theme_flag,
        sun_on: theme_flag,
      }"
      src="../assets/imgs/sun.png"
      alt=""
    />
    <img
      class="moon_icon"
      :class="{
        moon_on: !theme_flag,
        moon_off: theme_flag,
      }"
      src="../assets/imgs/moon.png"
      alt=""
    />
    <div @click="switch_theme_var" class="switcher">
      <svg
        :class="{
          switch_animate_on: !theme_flag,
          switch_animate_off: theme_flag,
        }"
        class="switcher__round"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="12" cy="12" r="12" fill="white" />
      </svg>
    </div>
  </div>
</template>

<style src="../styles/ThemeToggle.css"></style>
