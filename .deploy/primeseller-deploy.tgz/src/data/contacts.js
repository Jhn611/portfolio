export const contacts = {
  email: 'hello@primeseller.ru',
  telegram: 'https://t.me/PrimeSeller_wb_bot',
  telegramHandle: '@PrimeSeller_wb_bot'
};
