import { Mail, Send } from 'lucide-react';
import logo from '../../../assets/prime-seller-logo.svg';
import { contacts } from '../../../data/contacts';
import './Footer.css';

export default function Footer({ footerRef }) {
  return (
    <footer className="footer" id="footer" ref={footerRef}>
      <div className="section-shell footer__grid">
        <div>
          <a className="footer__brand" href="#top">
            <span><img src={logo} alt="" /></span>
            Prime Seller
          </a>
          <p>Оцифровка Wildberries, отчеты и AI-анализ для селлеров, которые принимают решения по данным.</p>
        </div>

        <div className="footer__contacts">
          <a href={`mailto:${contacts.email}`}><Mail size={18} /> {contacts.email}</a>
          <a href={contacts.telegram} target="_blank" rel="noreferrer"><Send size={18} /> Telegram</a>
        </div>
      </div>
    </footer>
  );
}
