import { useCallback, useEffect, useRef, useState } from 'react';

const SESSION_KEY = 'prime-seller:contact-shown';

export default function useContactModal(footerRef) {
  const [isOpen, setIsOpen] = useState(false);
  const [selection, setSelection] = useState(null);
  const hasShown = useRef(false);
  const observerRef = useRef(null);

  const openContact = useCallback((plan = null) => {
    hasShown.current = true;
    observerRef.current?.disconnect();
    try {
      window.sessionStorage.setItem(SESSION_KEY, '1');
    } catch {
      // The ref still prevents repeat prompts when browser storage is unavailable.
    }
    setSelection(plan);
    setIsOpen(true);
  }, []);

  const closeContact = useCallback(() => setIsOpen(false), []);

  useEffect(() => {
    try {
      hasShown.current = hasShown.current || window.sessionStorage.getItem(SESSION_KEY) === '1';
    } catch {
      // Keep the same behavior for the current page without session storage.
    }

    if (hasShown.current || !footerRef.current || !('IntersectionObserver' in window)) {
      return undefined;
    }

    const observer = new IntersectionObserver((entries) => {
      if (!hasShown.current && entries.some((entry) => entry.isIntersecting && entry.intersectionRatio >= 0.25)) {
        openContact();
      }
    }, { threshold: 0.25 });

    observerRef.current = observer;
    observer.observe(footerRef.current);
    return () => observer.disconnect();
  }, [footerRef, openContact]);

  return { isOpen, selection, openContact, closeContact };
}
