import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowUpRight, Check, Copy, Database, Mail, MessageCircle, Send, SlidersHorizontal, X } from 'lucide-react';
import logo from '../../assets/prime-seller-logo.svg';
import { contacts } from '../../data/contacts';
import './ContactModal.css';

export default function ContactModal({ isOpen, onClose, selection }) {
  const dialogRef = useRef(null);
  const startedOutside = useRef(false);
  const titleId = useId();
  const descriptionId = useId();
  const [copyState, setCopyState] = useState('idle');

  useEffect(() => {
    if (!isOpen) return undefined;

    const dialog = dialogRef.current;
    const previousFocus = document.activeElement;
    const { scrollX, scrollY } = window;
    const body = document.body;
    const html = document.documentElement;
    const previousBodyStyles = {};
    const styles = {
      position: 'fixed',
      top: `-${scrollY}px`,
      left: `-${scrollX}px`,
      width: '100%',
      overflow: 'hidden',
      paddingRight: `${parseFloat(getComputedStyle(body).paddingRight) + window.innerWidth - html.clientWidth}px`
    };

    // Preserve the scroll position on touch devices and avoid a scrollbar layout shift.
    for (const [property, value] of Object.entries(styles)) {
      previousBodyStyles[property] = body.style[property];
      body.style[property] = value;
    }

    setCopyState('idle');
    dialog.showModal();

    return () => {
      dialog.close();
      Object.assign(body.style, previousBodyStyles);
      const scrollBehavior = html.style.scrollBehavior;
      html.style.scrollBehavior = 'auto';
      window.scrollTo(scrollX, scrollY);
      previousFocus?.focus({ preventScroll: true });
      html.style.scrollBehavior = scrollBehavior;
    };
  }, [isOpen]);

  const isOutside = (event) => {
    const rect = dialogRef.current.getBoundingClientRect();
    return event.clientX < rect.left || event.clientX > rect.right
      || event.clientY < rect.top || event.clientY > rect.bottom;
  };

  const copyEmail = async () => {
    setCopyState('copying');
    try {
      await navigator.clipboard.writeText(contacts.email);
      setCopyState('copied');
    } catch {
      setCopyState('error');
    }
  };

  const keepFocusInside = (event) => {
    if (event.key !== 'Tab') return;
    const controls = event.currentTarget.querySelectorAll('a[href], button:not([disabled])');
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  };

  const subject = selection ? `Prime Seller: тариф ${selection.name}` : 'Подключение Prime Seller';
  const body = selection
    ? `Здравствуйте! Интересует тариф ${selection.name}${selection.duration ? ` на ${selection.duration}, ${selection.price}` : ' с индивидуальными условиями'}.`
    : 'Здравствуйте! Хочу узнать подробнее о подключении Prime Seller.';
  const emailHref = `mailto:${contacts.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  return createPortal(
    <dialog
      aria-describedby={descriptionId}
      aria-labelledby={titleId}
      className="contact-modal"
      onCancel={(event) => { event.preventDefault(); onClose(); }}
      onKeyDown={keepFocusInside}
      onClick={(event) => {
        if (startedOutside.current && isOutside(event)) onClose();
        startedOutside.current = false;
      }}
      onPointerDown={(event) => { startedOutside.current = isOutside(event); }}
      ref={dialogRef}
    >
      <div className="contact-modal__header">
        <div className="contact-modal__brand">
          <span className="contact-modal__logo"><img src={logo} alt="" /></span>
          <span>Prime Seller<small>Команда сервиса</small></span>
        </div>
        <button autoFocus className="contact-modal__close" onClick={onClose} type="button" aria-label="Закрыть окно" title="Закрыть окно">
          <X size={22} aria-hidden="true" />
        </button>
      </div>

      <h2 id={titleId}>Обсудим ваш магазин</h2>
      <p className="contact-modal__description" id={descriptionId}>
        Поможем подключить Prime Seller и разобраться в данных вашего бизнеса на Wildberries.
      </p>

      {selection && (
        <div className="contact-modal__selection" aria-label="Выбранный тариф">
          <div><small>Ваш выбор</small><strong>Тариф {selection.name}</strong></div>
          <div className="contact-modal__price">
            <strong>{selection.price}</strong>
            {selection.duration && <small>за {selection.duration}{selection.discount > 0 ? `, скидка ${selection.discount}%` : ''}</small>}
          </div>
        </div>
      )}

      <div className="contact-modal__methods">
        <a className="contact-modal__telegram" href={contacts.telegram} target="_blank" rel="noopener noreferrer">
          <Send size={24} aria-hidden="true" />
          <span><strong>Написать в Telegram</strong><small>{contacts.telegramHandle}</small></span>
          <ArrowUpRight size={22} aria-hidden="true" />
        </a>
        <div className="contact-modal__email-row">
          <a className="contact-modal__email" href={emailHref}>
            <Mail size={24} aria-hidden="true" />
            <span><small>Электронная почта</small><strong>{contacts.email}</strong></span>
          </a>
          <button
            aria-label={copyState === 'copied' ? 'Почта скопирована' : 'Скопировать почту'}
            className="contact-modal__copy"
            disabled={copyState === 'copying'}
            onClick={copyEmail}
            title={copyState === 'copied' ? 'Почта скопирована' : 'Скопировать почту'}
            type="button"
          >
            {copyState === 'copied' ? <Check size={20} aria-hidden="true" /> : <Copy size={20} aria-hidden="true" />}
          </button>
        </div>
      </div>

      <p className="contact-modal__status" role="status">
        {copyState === 'copied' && 'Почта скопирована'}
        {copyState === 'error' && 'Не удалось скопировать почту. Адрес доступен выше.'}
      </p>
      <ul className="contact-modal__topics" aria-label="С чем поможем">
        <li><Database size={16} aria-hidden="true" />Подключение WB</li>
        <li><SlidersHorizontal size={16} aria-hidden="true" />Подбор тарифа</li>
        <li><MessageCircle size={16} aria-hidden="true" />Вопросы по сервису</li>
      </ul>
    </dialog>,
    document.body
  );
}
