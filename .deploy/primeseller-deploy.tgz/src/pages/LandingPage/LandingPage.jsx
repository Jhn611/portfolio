import { useRef } from 'react';
import ContactModal, { useContactModal } from '../../components/ContactModal';
import Footer from '../../components/layout/Footer';
import Header from '../../components/layout/Header';
import AiTable from '../../components/sections/AiTable';
import Features from '../../components/sections/Features';
import Hero from '../../components/sections/Hero';
import Pricing from '../../components/sections/Pricing';
import Testimonials from '../../components/sections/Testimonials';
import VideoReview from '../../components/sections/VideoReview';

export default function LandingPage() {
  const footerRef = useRef(null);
  const { isOpen, selection, openContact, closeContact } = useContactModal(footerRef);

  return (
    <>
      <span id="top" />
      <Header onContactOpen={openContact} />
      <main>
        <Hero />
        <Pricing onContactOpen={openContact} />
        <VideoReview />
        <Testimonials />
        <Features />
        <AiTable />
      </main>
      <Footer footerRef={footerRef} />
      <ContactModal isOpen={isOpen} onClose={closeContact} selection={selection} />
    </>
  );
}
